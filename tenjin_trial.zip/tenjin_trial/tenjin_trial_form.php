<?php 
require_once("{$CFG->libdir}/formslib.php");
require_once($CFG->dirroot.'/blocks/tenjin_trial/lib.php');

class tenjin_trial_form extends moodleform{
    function definition(){
        $mform =& $this->_form;
        $mform->addElement('header','displayinfo', get_string('textfields','block_tenjin_trial'));
        $mform->addElement('text', 'pagetitle',get_string('pagetitle','block_tenjin_trial'));
        $mform->setType('pagetitle', PARAM_RAW);
        $mform->addRule('pagetitle', null, 'required', null, 'client');

        $mform->addElement('htmleditor', 'displaytext', get_string('displayedhtml', 'block_tenjin_trial'));
        $mform->setType('displaytext', PARAM_RAW);
        $mform->addRule('displaytext', null, 'required', null,'client');
    
        //adding a filepicker
        $mform->addElement('filepicker','filename',get_string('file'), null, array('accepted_types'=>'*'));

        //adding picture fields grouping
        $mform->addElement('header', 'picfield', get_string('picturefields', 'block_tenjin_trial', null, false));

        //yes/no picture select option
        $mform->addElement('selectyesno','displaypicture',get_string('displaypicture','block_tenjin_trial'));
        $mform->setDefault('displaypicture',1);

        //image selector radio buttons
        $images = block_tenjin_trial_images();
        $radioarray = array();
        for($i = 0; $i < count($images); $i++){
            $radioarray[]= &$mform->createElement('radio', 'picture', '', $images[$i], $i);
        }
        $mform->addGroup($radioarray, 'radioar', get_string('pictureselect', 'block_tenjin_trial'), array(' '), FALSE);

        $attributes = array('size'=>'50', 'maxlength' => '100');

        $mform->addElement('text', 'description', get_string('picturedesc','block_tenjin_trial', $attributes));
        $mform->setType('description', PARAM_TEXT);

        //adding a form header
        $mform->addElement('header','optional', get_string('optional','form'), null,false);

        //lets hide the date/time w/i the optional(advanced) form controls
        $mform->addElement('date_time_selector', 'displaydate', get_string('displaydate', 'block_tenjin_trial'), array('optional'=>true));
        $mform->setAdvanced('optional');

        $this->add_action_buttons(); //$this is used as add_action_buttons is outside the scope of $mform

        //we gotta keep track of hidden elements
        //are populated in the view.php file 
        $mform->addElement('hidden', 'blockid');
        $mform->addElement('hidden', 'courseid');
        $mform->addElement('hidden', 'id', '0');
    }
}
?>