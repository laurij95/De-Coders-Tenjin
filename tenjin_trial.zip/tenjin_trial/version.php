<?php 
$plugin->component = 'block_tenjin_trial';
$plugin->version = 2020031206;
$plugin->requires = 2019111800;