<?php 
function block_tenjin_trial_images(){
    return array(html_writer::tag('img','', array('alt'=>get_string('red','block_tenjin_trial'),'src' => "pix/picture0.gif")),
                html_writer::tag('img','', array('alt'=>get_string('blue','block_tenjin_trial'),'src' => "pix/picture1.gif")),
                html_writer::tag('img','', array('alt'=>get_string('green','block_tenjin_trial'),'src' => "pix/picture2.gif")));
}

//handles the page display
function block_tenjin_trial_print_page($tenjin_trial, $return = false){

    //add page title
    global $OUTPUT, $COURSE;
    $display = $OUTPUT->heading($tenjin_trial->pagetitle);

    //add a box to put around the rest of the elements to be displayed
    $display .= $OUTPUT->box_start();

    //display the date
    if($tenjin_trial->displaydate){       
        //lets put it in a div
        $display .= html_writer::start_tag('div', array('class' => 'tenjin_trial displaydate'));
        $display .= userdate($tenjin_trial->displaydate);
        $display .= html_writer::end_tag('div');
    }

    $display .= clean_text($tenjin_trial->displaytext);

    //close le box
    $display .= $OUTPUT->box_end();

    //display the picture
    if($tenjin_trial->displaypicture){
        $display .= $OUTPUT->box_start();
        $images = block_tenjin_trial_images();
        $display .= $images[$tenjin_trial->picture];
        $display .= html_writer::start_tag('p');
        $display .= clean_text($tenjin_trial->description);
        $display .= html_writer::end_tag('p');
        $display .= $OUTPUT->box_end();
    }

    if ($return){
        return $display;
    }else{
        echo $display;
    }


}
?>