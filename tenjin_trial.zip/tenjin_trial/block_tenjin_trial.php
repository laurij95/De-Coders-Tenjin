<?php

class block_tenjin_trial extends block_base {
    public function init(){
        $this->title = get_string('tenjin_trial','block_tenjin_trial' );
    }

    //allowing the block to appear on pages
    function applicable_formats(){
        return array(
            'site-index'=> true,
            'course-view'=> true,
            'course-view-social'=> false,
            'mod'=> true,
            'mod-quiz'=> false
        );
    }

    public function get_content(){
        if ($this-> content !== null) {
            return $this->content;
        }

        $this->content = new stdClass;
        $this-> content->text = 'The content of our Tenjin trial block!';
        // $this-> content->footer = 'Theres a footer here...';

        global $COURSE, $DB, $PAGE;
        $context = context_course::instance($COURSE->id);

        //are we in editing mode? Yes? Nice, now we can manage some pages in here

        $canmanage = has_capability('block/tenjin_trial:managepages', $context) && $PAGE->user_is_editing($this->instance->id);
        $canview = has_capability('block/tenjin_trial:viewpages', $context);


        if(!empty($this->config->text)){
            $this->content->text = $this->config->text;
        }

        //basically we gotta link this page w the DB :)
        if($tenjin_trial_pages = $DB->get_records('block_tenjin_trial', array('blockid' => $this->instance->id))){
            
            //makes a list element
            $this->content->text .= html_writer::start_tag('ul');
            
            foreach($tenjin_trial_pages as $tenjin_trial_page){
                
                if($canmanage){

                    //edit
                    $pageparam = array ('blockid' => $this->instance->id, 'courseid' =>$COURSE->id, 'id'=>$tenjin_trial_page->id);
                    $editurl = new moodle_url('/blocks/tenjin_trial/view.php', $pageparam);
                    $editpicurl = new moodle_url('/pix/t/edit.png');
                    $edit = html_writer::link($editurl, html_writer::tag('img','',array('src' => $editpicurl, 'alt'=> get_string('edit'))));

                    //delete
                    $deleteparam = array('id' =>$tenjin_trial_page->id, 'courseid'=>$COURSE->id );
                    $deleteurl = new moodle_url('/blocks/tenjin_trial/delete.php', $deleteparam);
                    $deletepicurl = new moodle_url('/pix/t/delete.png');
                    $delete = html_writer::link($deleteurl, html_Writer::tag('img', '', array('src'=>$deletepicurl, 'alt'=>get_string('delete'))));

                }else{
                    $edit ='';
                    $delete = '';
                }

                if($canview){
                    //for each record make a list item
                    $pageurl = new moodle_url('/blocks/tenjin_trial/view.php', array('blockid' => $this->instance->id, 'courseid' =>$COURSE->id, 'id' => $tenjin_trial_page->id, 'viewpage' => true));
                    $this->content->text .= html_writer::start_tag('li');
                    $this->content->text .= html_writer::link($pageurl, $tenjin_trial_page->pagetitle);
                    $this->content->text .= $edit;
                    $this->content->text .= $delete;
                    $this->content->text .= html_writer::end_tag('li');
                }else{
                    $this->content->text .= html_writer::tag('div', $tenjin_trial_page->pagetitle);
                }
               
            }
            $this->content->text .= html_writer::end_tag('ul');
        }

        if(has_capability('block/tenjin_trial:managepages', $context)){
            $url = new moodle_url('/blocks/tenjin_trial/view.php', array('blockid' => $this->instance->id, 'courseid' => $COURSE->id));
            $this->content->footer = html_writer::link($url, get_string('addpage', 'block_tenjin_trial'));
        } else {
            $this->content->footer = '';
        }
        

        return $this->content;
    }

    public function specialization(){
        if(isset($this->config)){
            if(empty($this->config->title)){
                $this->title = get_string('defaulttitle', 'block_tenjin_trial');
            }else{
                $this->title = $this->config->title;
            }

            if(empty($this->config->text)){
                $this->config->text = get_string('defaulttext','block_tenjin_trial');
            }
        }     
    }

    //the ability of adding mxple instances of our block to a single course
    public function instance_allow_multiple(){
        return true;
    }

    //enabling global configuration
    function has_config(){
        return true;
    }

    //capturing the form processing from edit_form and removing html tags
    // public function instance_config_save($data, $nolongerused = false){
    //     $data = stripslashes_recursive($data);
    //     $this->config = $data;
    //     return set_field('block_instance', 
    //                     'configdata', 
    //                     base64_encode(serialize($data)), 
    //                     'id', 
    //                     $this->instance->id);
    // }

    public function instance_config_save($data, $nolongerused = false){
        if (get_config('tenjin_trial', 'Allow_HTML')=='1') {
            $data->text = strip_tags($data->text);
        }
        return parent::instance_config_save($data,$nolongerused);
    }

    public function hide_header(){
        return true;
    }

    public function html_attributes(){
        $attributes = parent::html_attributes(); //get default values
        $attributes['class'] .= 'block_'. $this->name(); //append our class to class attribute 

        return $attributes;
    }

    //to delete an instance 
    public function instance_delete(){
        global $DB;
        
        //retrieve the record with that specific instance id and bippity boppity boo, its gone!
        $DB->delete_records('block_tenjin_trial', array('blockid' => $this->instance->id));
    }

   


}
?>