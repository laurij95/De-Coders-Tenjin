<?php 
require_once('../../config.php');
require_once('tenjin_trial_form.php');

global $DB, $OUTPUT, $PAGE;

//check for all required variables
$courseid = required_param('courseid',PARAM_INT);

$blockid = required_param('blockid', PARAM_INT);

$id = optional_param('id', 0, PARAM_INT);

$viewpage = optional_param('viewpage', false, PARAM_BOOL);

if(!$course = $DB->get_record('course', array('id' => $courseid))){
    print_error('invalidcourse', 'block_tenjin_trial', $courseid);
}
//you gotta be logged in b
require_login($course);

//adding role: you can manage the page
require_capability('block/tenjin_trial:managepages', context_course::instance($courseid));


//basically setting some aspects of the PAGE object/variable
$PAGE->set_url('/blocks/tenjin_trial/view.php', array('id'=>$courseid));
$PAGE->set_pagelayout('standard');
$PAGE->set_heading(get_string('edithtml', 'block_tenjin_trial'));

$settingsnode = $PAGE->settingsnav->add(get_string('tenjintrialsettings','block_tenjin_trial'));
$editurl = new moodle_url('/blocks/tenjin_trial/view.php', array('id'=>$id, 'courseid'=>$courseid, 'blockid'=>$blockid));
$editnode = $settingsnode->add(get_string('editpage','block_tenjin_trial'), $editurl);
$editnode->make_active();


$tenjin_trial = new tenjin_trial_form();

$toform['blockid'] = $blockid;
$toform['courseid'] = $courseid;
$toform['id'] = $id;
$tenjin_trial->set_data($toform);

if($tenjin_trial->is_cancelled()){
    
    //cancellled forms redirect to the course main page
    $courseurl = new moodle_url('/course/view.php', array('id'=>$id));
    redirect($courseurl);

}else if ($fromform = $tenjin_trial->get_data()){
    
    //appropriately act on & store the submitted data
    if($fromform->id!=0){
        if(!$DB->update_record('block_tenjin_trial', $fromform)){
            print_error('updateerror', 'block_tenjin_trial');
        }
    }else{
        if(!$DB->insert_record('block_tenjin_trial', $fromform)){
            print_error('inserterror','block_tenjin_trial');
        }
    }
    //as of now, just redirect to course main page
    $courseurl = new moodle_url('/course/view.php', array('id' => $courseid));
    //print_object($fromform); //prints out data from mixed types
    
    //sends you back to the course page
    redirect($courseurl);
}else{

    //form didnt validate or this is the first display
    $site = get_site();
    echo $OUTPUT->header();

    if ($id){
        $tenjin_trial_page = $DB->get_record('block_tenjin_trial', array('id'=>$id));
        if($viewpage){
            block_tenjin_trial_print_page($tenjin_trial_page);
        }else{
           $tenjin_trial->set_data($tenjin_trial_page);
           $tenjin_trial->display();
        }
    } else {
        $tenjin_trial->display();
    }
    echo $OUTPUT->footer();
}




?>