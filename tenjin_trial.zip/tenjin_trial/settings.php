<?php 
//global configuration: touching on all instances of a specific block

$settings->add(new admin_setting_heading(
            'headerconfig',
            get_string('headerconfig', 'block_tenjin_trial'),
            get_string('descconfig', 'block_tenjin_trial')
        ));
$settings->add(new admin_setting_configcheckbox(
        'tenjin_trial/Allow_HTML',
        get_string('labelallowhtml','block_tenjin_trial'),
        get_string('descallowhtml','block_tenjin_trial'),
        '0'
        ));
?>